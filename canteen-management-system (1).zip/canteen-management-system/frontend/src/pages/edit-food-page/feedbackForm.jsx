import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import Loader from "../../components/loader/Loader";
import { editFoodItem, getSingleFoodItem } from "../../redux/food/food.actions";
import "./EditFoodPage.css";

const FeedBack = ({
  //   isAuthenticated,
  loading,
  getSingleFoodItem,
  history,
  match,
  food,
  editFoodItem,
}) => {
  const [foodType, setFoodType] = useState("");

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");

  const [image, setImage] = useState("");

  function handlechange(e) {
    const value = e.target.value;
    setName(value);
  }
  useEffect(() => {
    getSingleFoodItem(match.params.id);
    setFoodType(food?.foodType);
    setName(food?.name);
    setPrice(food?.price);
    setQuantity(food?.quantity);
    setImage(food?.image);
  }, [getSingleFoodItem, match, food]);

  const onSubmit = (e) => {
    // e.preventDefault();

    // const formdata = new FormData();
    // formdata.append("foodType", foodType);
    // formdata.append("name", name);
    // formdata.append("price", price);
    // formdata.append("quantity", quantity);
    // formdata.append("image", image);
    // editFoodItem(formdata, match.params.id, history);
  };

  return (
    <div className="root">
      {/* {loading && <Loader />} */}
      <div className="add-food-div">
        <div>
          <h1>Feedback</h1>

          <form onSubmit={onSubmit}>
            <label>What can we improve...</label>
            <textarea
              type="text-area"
              name="name"
              className="input"
              onChange={(e) => setName(e.target.value)}
              //   onChange={handlechange}
              value={name}
            />

            <br />
            <button><Link to="" style={{"textDecoration":"none","color":"#fff"}}>Submit</Link></button>
          </form>
        </div>
        <div></div>
      </div>
    </div>
  );
};

const mapStateToProps = (state) => ({
  //   isAuthenticated: state.auth.isAuthenticated,
  loading: state.food.loading,
  food: state.food.food,
});

export default connect(mapStateToProps, { getSingleFoodItem, editFoodItem })(
  FeedBack
);
