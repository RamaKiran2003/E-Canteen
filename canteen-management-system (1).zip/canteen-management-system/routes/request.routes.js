const express = require("express");
const Food = require("../models/food.models");
const User = require("../models/auth.models");
const Request = require("../models/request.models")
const router = express.Router();
const auth = require("../middleware/auth");
const upload = require("../middleware/cloudinary");
const { check, validationResult } = require("express-validator");


router.post(
    "/request-food",
    [
      auth,
      upload,
      [
        auth,
        check("name", "Food name is required").not().isEmpty(),
        check("foodType", "Food category is required").not().isEmpty(),
        check("quantity", "Qunatity is required").not().isEmpty(),
      ],
    ],
    async (req, res) => {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
  
      try {
        const user = await User.findById(req.user.id);
        if (user.isAdmin) {
          const { foodType, name, price, quantity } = req.body;
  
          const food = new Food({
            foodType,
            name,
            price,
            quantity,
            image: req.file.path,
          });
          await food.save();
          res.json({ msg: "Added item successfully", food });
        } else {
          const { foodType, name, quantity } = req.body;
  
          const request = new Request({
            foodType,
            name,
            quantity
          });
          await request.save();
          res.json({ msg: "Requested item successfully", request });
        }
      } catch (error) {
        console.error(error.message);
        return res.status(500).send(error.message);
      }
    }
  );

  module.exports = router;