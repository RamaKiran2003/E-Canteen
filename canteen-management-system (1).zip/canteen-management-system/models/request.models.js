const mongoose = require('mongoose');
const RequestSchema = new mongoose.Schema({
  foodType: {
    type: String,
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  quantity:{
    type:String,
    required:true
  }
});

module.exports = mongoose.model('request', RequestSchema);
